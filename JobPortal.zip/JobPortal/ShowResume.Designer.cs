﻿namespace JobPortal
{
    partial class ShowResume
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShowResume));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlButtom = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.data_employment_history = new System.Windows.Forms.DataGridView();
            this.data_academic_qualification = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_permanent_address = new System.Windows.Forms.Label();
            this.lb_gender = new System.Windows.Forms.Label();
            this.lb_nationality = new System.Windows.Forms.Label();
            this.lb_mothers_name = new System.Windows.Forms.Label();
            this.lb_religion = new System.Windows.Forms.Label();
            this.lb_dob = new System.Windows.Forms.Label();
            this.lb_marital_status = new System.Windows.Forms.Label();
            this.lb_fathers_name = new System.Windows.Forms.Label();
            this.pb_user_image = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_expertise = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_mobile_1 = new System.Windows.Forms.Label();
            this.lb_address = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlButtom.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_employment_history)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_academic_qualification)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user_image)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(194, 79);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.Indigo;
            this.pnlTop.Controls.Add(this.btnBack);
            this.pnlTop.Controls.Add(this.btnLogout);
            this.pnlTop.Controls.Add(this.panel1);
            this.pnlTop.Controls.Add(this.pictureBox1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1097, 73);
            this.pnlTop.TabIndex = 5;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(877, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(101, 55);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(984, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(101, 55);
            this.btnLogout.TabIndex = 5;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(3, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1101, 435);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("Old English Text MT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(603, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Build Your Carrer With Us";
            // 
            // pnlButtom
            // 
            this.pnlButtom.BackColor = System.Drawing.Color.Indigo;
            this.pnlButtom.Controls.Add(this.label1);
            this.pnlButtom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtom.Location = new System.Drawing.Point(0, 646);
            this.pnlButtom.Name = "pnlButtom";
            this.pnlButtom.Size = new System.Drawing.Size(1097, 69);
            this.pnlButtom.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 73);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1097, 573);
            this.panel2.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.data_employment_history);
            this.panel3.Controls.Add(this.data_academic_qualification);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.lb_permanent_address);
            this.panel3.Controls.Add(this.lb_gender);
            this.panel3.Controls.Add(this.lb_nationality);
            this.panel3.Controls.Add(this.lb_mothers_name);
            this.panel3.Controls.Add(this.lb_religion);
            this.panel3.Controls.Add(this.lb_dob);
            this.panel3.Controls.Add(this.lb_marital_status);
            this.panel3.Controls.Add(this.lb_fathers_name);
            this.panel3.Controls.Add(this.pb_user_image);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.lb_expertise);
            this.panel3.Controls.Add(this.lb);
            this.panel3.Controls.Add(this.lb_email);
            this.panel3.Controls.Add(this.lb_mobile_1);
            this.panel3.Controls.Add(this.lb_address);
            this.panel3.Controls.Add(this.lb_name);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1097, 573);
            this.panel3.TabIndex = 0;
            // 
            // data_employment_history
            // 
            this.data_employment_history.AllowUserToAddRows = false;
            this.data_employment_history.AllowUserToDeleteRows = false;
            this.data_employment_history.AllowUserToResizeRows = false;
            this.data_employment_history.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.data_employment_history.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_employment_history.Location = new System.Drawing.Point(32, 731);
            this.data_employment_history.Name = "data_employment_history";
            this.data_employment_history.ShowEditingIcon = false;
            this.data_employment_history.Size = new System.Drawing.Size(978, 125);
            this.data_employment_history.TabIndex = 32;
            // 
            // data_academic_qualification
            // 
            this.data_academic_qualification.AllowUserToAddRows = false;
            this.data_academic_qualification.AllowUserToDeleteRows = false;
            this.data_academic_qualification.AllowUserToResizeRows = false;
            this.data_academic_qualification.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.data_academic_qualification.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_academic_qualification.Location = new System.Drawing.Point(32, 198);
            this.data_academic_qualification.Name = "data_academic_qualification";
            this.data_academic_qualification.Size = new System.Drawing.Size(978, 125);
            this.data_academic_qualification.TabIndex = 31;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightGray;
            this.panel6.Controls.Add(this.label8);
            this.panel6.Location = new System.Drawing.Point(32, 415);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(978, 30);
            this.panel6.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(172, 29);
            this.label8.TabIndex = 0;
            this.label8.Text = "Personal Details:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(32, 342);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(978, 30);
            this.panel4.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(245, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "Skills and Specialization:";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightGray;
            this.panel5.Controls.Add(this.label22);
            this.panel5.Location = new System.Drawing.Point(32, 694);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(978, 30);
            this.panel5.TabIndex = 27;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(4, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(212, 29);
            this.label22.TabIndex = 0;
            this.label22.Text = "Employment History:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightGray;
            this.panel7.Controls.Add(this.label3);
            this.panel7.Location = new System.Drawing.Point(32, 161);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(978, 30);
            this.panel7.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(236, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Academic Qualification:";
            // 
            // lb_permanent_address
            // 
            this.lb_permanent_address.AutoSize = true;
            this.lb_permanent_address.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_permanent_address.Location = new System.Drawing.Point(193, 656);
            this.lb_permanent_address.Name = "lb_permanent_address";
            this.lb_permanent_address.Size = new System.Drawing.Size(19, 27);
            this.lb_permanent_address.TabIndex = 18;
            this.lb_permanent_address.Text = ":";
            // 
            // lb_gender
            // 
            this.lb_gender.AutoSize = true;
            this.lb_gender.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_gender.Location = new System.Drawing.Point(193, 542);
            this.lb_gender.Name = "lb_gender";
            this.lb_gender.Size = new System.Drawing.Size(19, 27);
            this.lb_gender.TabIndex = 17;
            this.lb_gender.Text = ":";
            // 
            // lb_nationality
            // 
            this.lb_nationality.AutoSize = true;
            this.lb_nationality.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nationality.Location = new System.Drawing.Point(193, 599);
            this.lb_nationality.Name = "lb_nationality";
            this.lb_nationality.Size = new System.Drawing.Size(19, 27);
            this.lb_nationality.TabIndex = 16;
            this.lb_nationality.Text = ":";
            // 
            // lb_mothers_name
            // 
            this.lb_mothers_name.AutoSize = true;
            this.lb_mothers_name.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mothers_name.Location = new System.Drawing.Point(193, 485);
            this.lb_mothers_name.Name = "lb_mothers_name";
            this.lb_mothers_name.Size = new System.Drawing.Size(19, 27);
            this.lb_mothers_name.TabIndex = 15;
            this.lb_mothers_name.Text = ":";
            // 
            // lb_religion
            // 
            this.lb_religion.AutoSize = true;
            this.lb_religion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_religion.Location = new System.Drawing.Point(193, 628);
            this.lb_religion.Name = "lb_religion";
            this.lb_religion.Size = new System.Drawing.Size(19, 27);
            this.lb_religion.TabIndex = 14;
            this.lb_religion.Text = ":";
            // 
            // lb_dob
            // 
            this.lb_dob.AutoSize = true;
            this.lb_dob.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_dob.Location = new System.Drawing.Point(193, 514);
            this.lb_dob.Name = "lb_dob";
            this.lb_dob.Size = new System.Drawing.Size(19, 27);
            this.lb_dob.TabIndex = 13;
            this.lb_dob.Text = ":";
            // 
            // lb_marital_status
            // 
            this.lb_marital_status.AutoSize = true;
            this.lb_marital_status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_marital_status.Location = new System.Drawing.Point(193, 571);
            this.lb_marital_status.Name = "lb_marital_status";
            this.lb_marital_status.Size = new System.Drawing.Size(19, 27);
            this.lb_marital_status.TabIndex = 12;
            this.lb_marital_status.Text = ":";
            // 
            // lb_fathers_name
            // 
            this.lb_fathers_name.AutoSize = true;
            this.lb_fathers_name.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fathers_name.Location = new System.Drawing.Point(193, 457);
            this.lb_fathers_name.Name = "lb_fathers_name";
            this.lb_fathers_name.Size = new System.Drawing.Size(19, 27);
            this.lb_fathers_name.TabIndex = 11;
            this.lb_fathers_name.Text = ":";
            // 
            // pb_user_image
            // 
            this.pb_user_image.Location = new System.Drawing.Point(834, 20);
            this.pb_user_image.Name = "pb_user_image";
            this.pb_user_image.Size = new System.Drawing.Size(125, 135);
            this.pb_user_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_user_image.TabIndex = 26;
            this.pb_user_image.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(35, 664);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(160, 27);
            this.label17.TabIndex = 9;
            this.label17.Text = "Permnt Addrs";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(35, 542);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 27);
            this.label11.TabIndex = 8;
            this.label11.Text = "Gender";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(35, 599);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 27);
            this.label16.TabIndex = 7;
            this.label16.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(35, 485);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 27);
            this.label5.TabIndex = 6;
            this.label5.Text = "Mothers Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(35, 628);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 27);
            this.label15.TabIndex = 5;
            this.label15.Text = "Religion";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(35, 514);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(146, 27);
            this.label10.TabIndex = 24;
            this.label10.Text = "Date of Birth";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(35, 571);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(159, 27);
            this.label14.TabIndex = 25;
            this.label14.Text = "Marital Status";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(35, 457);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 27);
            this.label6.TabIndex = 19;
            this.label6.Text = "Fathers Name";
            // 
            // lb_expertise
            // 
            this.lb_expertise.AutoSize = true;
            this.lb_expertise.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_expertise.Location = new System.Drawing.Point(193, 384);
            this.lb_expertise.Name = "lb_expertise";
            this.lb_expertise.Size = new System.Drawing.Size(19, 27);
            this.lb_expertise.TabIndex = 20;
            this.lb_expertise.Text = ":";
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb.Location = new System.Drawing.Point(35, 384);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(111, 27);
            this.lb.TabIndex = 21;
            this.lb.Text = "Expertise";
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email.Location = new System.Drawing.Point(35, 131);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(102, 27);
            this.lb_email.TabIndex = 22;
            this.lb_email.Text = "lb_email";
            // 
            // lb_mobile_1
            // 
            this.lb_mobile_1.AutoSize = true;
            this.lb_mobile_1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mobile_1.Location = new System.Drawing.Point(35, 106);
            this.lb_mobile_1.Name = "lb_mobile_1";
            this.lb_mobile_1.Size = new System.Drawing.Size(142, 27);
            this.lb_mobile_1.TabIndex = 23;
            this.lb_mobile_1.Text = "lb_mobile_1";
            // 
            // lb_address
            // 
            this.lb_address.AutoSize = true;
            this.lb_address.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_address.Location = new System.Drawing.Point(35, 84);
            this.lb_address.Name = "lb_address";
            this.lb_address.Size = new System.Drawing.Size(117, 27);
            this.lb_address.TabIndex = 10;
            this.lb_address.Text = "lb_adress";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Lucida Sans Typewriter", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.ForeColor = System.Drawing.Color.Purple;
            this.lb_name.Location = new System.Drawing.Point(35, 53);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(134, 33);
            this.lb_name.TabIndex = 4;
            this.lb_name.Text = "lb_name";
            // 
            // ShowResume
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1097, 715);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlButtom);
            this.Controls.Add(this.pnlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ShowResume";
            this.Text = "ClientShow";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlButtom.ResumeLayout(false);
            this.pnlButtom.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_employment_history)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_academic_qualification)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_user_image)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlButtom;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView data_employment_history;
        private System.Windows.Forms.DataGridView data_academic_qualification;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_permanent_address;
        private System.Windows.Forms.Label lb_gender;
        private System.Windows.Forms.Label lb_nationality;
        private System.Windows.Forms.Label lb_mothers_name;
        private System.Windows.Forms.Label lb_religion;
        private System.Windows.Forms.Label lb_dob;
        private System.Windows.Forms.Label lb_marital_status;
        private System.Windows.Forms.Label lb_fathers_name;
        private System.Windows.Forms.PictureBox pb_user_image;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_expertise;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.Label lb_mobile_1;
        private System.Windows.Forms.Label lb_address;
        private System.Windows.Forms.Label lb_name;
    }
}